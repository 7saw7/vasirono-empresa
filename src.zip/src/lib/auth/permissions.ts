import { ROLES, type AppRole } from "@/lib/constants/roles";

export const PERMISSIONS = {
  manageCompany: "manage_company",
  manageBranches: "manage_branches",
  viewAnalytics: "view_analytics",
  manageReviews: "manage_reviews",
  verifyBusiness: "verify_business",
  manageSettings: "manage_settings",
} as const;

export type AppPermission =
  (typeof PERMISSIONS)[keyof typeof PERMISSIONS];

const ROLE_PERMISSIONS: Record<AppRole, AppPermission[]> = {
  [ROLES.superAdmin]: [
    PERMISSIONS.manageCompany,
    PERMISSIONS.manageBranches,
    PERMISSIONS.viewAnalytics,
    PERMISSIONS.manageReviews,
    PERMISSIONS.verifyBusiness,
    PERMISSIONS.manageSettings,
  ],
  [ROLES.backoffice]: [
    PERMISSIONS.verifyBusiness,
    PERMISSIONS.viewAnalytics,
  ],
  [ROLES.adminCompany]: [
    PERMISSIONS.manageCompany,
    PERMISSIONS.manageBranches,
    PERMISSIONS.viewAnalytics,
    PERMISSIONS.manageReviews,
    PERMISSIONS.manageSettings,
  ],
};

export function hasPermission(
  role: AppRole,
  permission: AppPermission
): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

export function hasAnyPermission(
  role: AppRole,
  permissions: AppPermission[]
): boolean {
  return permissions.some((permission) => hasPermission(role, permission));
}

export function hasAllPermissions(
  role: AppRole,
  permissions: AppPermission[]
): boolean {
  return permissions.every((permission) => hasPermission(role, permission));
}